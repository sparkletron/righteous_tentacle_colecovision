enum coleco_pins {
  // Port A: 22, 23, 24, 25, 26, 27, 28, 29: Address bus low half
  CA0 = 22, CA1, CA2, CA3, CA4, CA5, CA6, CA7,

  // Port B: 53, 52, 51, 50, 10, 11, 12, 13
  RESETNOT = 53, RESET = 52, INT = 51, QUAD = 50, MREQ = 10, IORQ, AD2000, AD4000,

  // Port C: 37, 36, 35, 34, 33, 32, 31, 30: Address bus high half
  CA8 = 37, CA9 = 36, CA10 = 35, CA11 = 34, CA12 = 33, CA13 = 32, CA14 = 31, CA15 = 30,

  // Port D: 21, 20, 19, 18, --, --, --, 38: Bus control
  IOMAPOVR = 21, MEMMAPOVR = 20, EXTRST = 19, XXXX0 = 18, /* NC0, NC1, NC2, */ BUSRQ = 38,

  // Port E: 0, 1, --, 5, 2, 3, --, --: Bus control
  SERIALRX = 0, SERIALTX = 1, /* NC3, */ NMI = 5, RFSH = 2, EXAUD = 3, /* NC4, NC5, */

  // Port F: A0, A1, A2, A3, A4, A5, A6, A7: Video DAC
  DAC0 = PIN_A0, DAC1 = PIN_A1, DAC2 = PIN_A2, DAC3 = PIN_A3, /* NC6, NC7, NC8, */ EXVIDEN = PIN_A7,

  // Port G: 41, 40, 39, --, --, 4, --: Clocks
  PCLK = 41, CLK2 = 40, CLK = 39, /* NC9, NC10, */ WAIT = 4, /* NC11, */

  // Port H: 17, 16, --, 6, 7, 8, 9, --: Bus control
  /* NC12, */ PULLUPSENSE = 16, /* NC14, */ BUSACK = 6, WR, RD, HALT, /* NC15, */
  
  // Port J: 15, 14, --, --, --, --, --, --: Bus control
  VDCRST = 15, M1 = 14, /* NC16, NC17, NC18, NC19, NC20, NC21, */
  
  // Port K: A8, A9, A10, A11, A12, A13, A14, A15: Not connected
  PULLUPA0 = A8, PULLUPA1, PULLUPEN, /* NC25, NC26, NC27, NC28, NC29, */

  // Port L: 49, 48, 47, 46, 45, 44, 43, 42:  Data
  CD0 = 49, CD1 = 48, CD2 = 47, CD3 = 46, CD4 = 45, CD5 = 44, CD6 = 43, CD7 = 42,
};


bool doBusAck(void);
void doBasicTests(void);
void doMemTests(void);
bool vramTest(void);
bool checkInput(void);
bool doExtVideoTest(void);

void resetTimer(void);
void delayClocks( uint16_t clocks );
