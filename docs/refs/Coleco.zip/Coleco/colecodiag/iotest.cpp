#include <Arduino.h>
#include "tests.h"

uint8_t readIO( uint16_t addr ) {
  PORTA = addr & 0xff;
  PORTC = addr >> 8;
  PORTH = 0b00010000; // Set read

  // Read status register
  DDRL = 0b00000000;  // Set data input
  PORTL = 0b00000000;
  
  PORTB = 0b00010000; // Activate IORQ
  for( int i = 0; i < 8; i++ ) { _NOP(); }
  uint8_t data = PINL;
  PORTB = 0b00110000; // Clear IORQ
  PORTH = 0b00110000; // Clear read

  PORTA = 0b00000000;
  PORTC = 0b00000000;
  return data;  
}

uint8_t readStatus() {
  return readIO( 0xBF );
}

void writeIO( uint8_t addr, uint8_t data ) {
  PORTA = addr & 0xff;
  PORTC = addr >> 8;
  DDRL = 0b11111111;
  PORTL = data;
  PORTH = 0b00100000; // Set write
  PORTB = 0b00010000; // Activate IORQ
  for( int i = 0; i < 8; i++ ) { _NOP(); }
  PORTB = 0b00110000; // Clear IORQ 
  PORTH = 0b00110000; // Clear write
  PORTL = 0b00000000;
}

void writeReg( uint8_t reg, uint8_t data ) {
  readStatus(); // Need to read status in order to write to a register

  writeIO( 0xBF, data );
  writeIO( 0xBF, reg | 0b10000000 );
}

void readAddr( uint16_t addr ) {
  readStatus(); // Need to read status in order to write to a register
  
  writeIO( 0xBF, addr & 0xff );
  writeIO( 0xBF, ( addr >> 8 ) | 0b00000000 );
}

void writeAddr( uint16_t addr ) {
  readStatus(); // Need to read status in order to write to a register
  
  writeIO( 0xBF, addr & 0xff );
  writeIO( 0xBF, ( addr >> 8 ) | 0b01000000 );
}

bool vramTest() {
  if( !doBusAck() )
  {
    return false;
  }

  Serial.println( "Testing video memory" );
  
  // Set up for writing to TMS99xx
  DDRA = 0b11111111; // Address low
  DDRC = 0b11111111; // Address high
  PORTB = 0b00110000; // IORQ and MREQ off
  DDRB = 0b00110000; // IORQ and MREQ
  PORTD |= 0b00000001; // Turn off I/O override
  DDRH = 0b00110000; // RD, WR
  PORTH = 0b00110000; // No mode

  // Set mode 0 with 16K memory, no display
  writeReg( 0, 0b00000000 );
  writeReg( 1, 0b10000000 );

  // Test all 1's
  Serial.println( "Testing 1's" );
  writeAddr( 0x0000 );

  // Prepare to write a string of 1's
  PORTA = 0xBE;
  DDRL = 0b11111111;
  PORTL = 0b11111111;
  PORTH = 0b00100000; // Set write

  for( uint16_t i = 0; i < 0x4000; i++ )
  {
    PORTB = 0b00010000; // Activate IORQ
    for( int i = 0; i < 16; i++ ) { _NOP(); } // 8us+ CSW pulse
    PORTB = 0b00110000; // Clear IORQ 
    for( int i = 0; i < 2; i++ ) { _NOP(); } // Data hold time after CSW high
  }

  delay( 1000 );  // Give RAM time to degrade

  // Read back memory
  readAddr( 0x0000 );
  PORTA = 0xBE;
  DDRL = 0b00000000;
  PORTH = 0b00010000; // Set read

  uint8_t errors1 = 0;
  
  for( uint16_t i = 0; i < 0x4000; i++ )
  {
    PORTB = 0b00010000;
    for( int i = 0; i < 16; i++ ) { _NOP(); } // 8us+ CSR pulse
    errors1 |= PINL ^ 0xff;
    PORTB = 0b00110000; // Clear IORQ 
  }

  // Test all 0's
  Serial.println( "Testing 0's" );
  writeAddr( 0x0000 );

  // Prepare to write a string of 0's
  PORTA = 0xBE;
  DDRL = 0b11111111;
  PORTL = 0b00000000;
  PORTH = 0b00100000; // Set write

  for( uint16_t i = 0; i < 0x4000; i++ )
  {
    PORTB = 0b00010000; // Activate IORQ
    for( int i = 0; i < 16; i++ ) { _NOP(); } // 8us+ CSW pulse
    PORTB = 0b00110000; // Clear IORQ 
    for( int i = 0; i < 2; i++ ) { _NOP(); } // Data hold time after CSW high
  }

  delay( 1000 );  // Give RAM time to degrade

  // Read back memory
  readAddr( 0x0000 );
  PORTA = 0xBE;
  DDRL = 0b00000000;
  PORTH = 0b00010000; // Set read

  uint8_t errors0 = 0;
  
  for( uint16_t i = 0; i < 0x4000; i++ )
  {
    PORTB = 0b00010000;
    for( int i = 0; i < 16; i++ ) { _NOP(); } // 8us+ CSR pulse
    errors0 |= PINL;
    PORTB = 0b00110000; // Clear IORQ 
  }

  // Test 01's
  Serial.println( "Testing 01's" );
  writeAddr( 0x0000 );

  // Prepare to write a string of 0's then 1's
  PORTA = 0xBE;
  DDRL = 0b11111111;
  PORTL = 0b00000000;
  PORTH = 0b00100000; // Set write

  for( uint16_t i = 0; i < 0x4000; i++ )
  {
    PORTB = 0b00010000; // Activate IORQ
    for( int i = 0; i < 16; i++ ) { _NOP(); } // 8us+ CSW pulse
    PORTB = 0b00110000; // Clear IORQ
    for( int i = 0; i < 8; i++ ) { _NOP(); } // Data hold time after CSW high
    PINL = 0b11111111; // Toggle bits
  }

  delay( 1000 );  // Give RAM time to degrade

  // Read back memory
  readAddr( 0x0000 );
  PORTA = 0xBE;
  DDRL = 0b00000000;
  PORTH = 0b00010000; // Set read

  uint8_t errors01 = 0;

  uint8_t eval = 0;
  for( uint16_t i = 0; i < 0x4000; i++ )
  {
    PORTB = 0b00010000;
    for( int i = 0; i < 16; i++ ) { _NOP(); } // 8us+ CSR pulse
    errors01 |= PINL ^ eval;
    PORTB = 0b00110000; // Clear IORQ 
    eval ^= 0xff;
  }

  // Test 10's
  Serial.println( "Testing 10's" );
  writeAddr( 0x0000 );

  // Prepare to write a string of 0's then 1's
  PORTA = 0xBE;
  DDRL = 0b11111111;
  PORTL = 0b11111111;
  PORTH = 0b00100000; // Set write

  for( uint16_t i = 0; i < 0x4000; i++ )
  {
    PORTB = 0b00010000; // Activate IORQ
    for( int i = 0; i < 16; i++ ) { _NOP(); } // 8us+ CSW pulse
    PORTB = 0b00110000; // Clear IORQ
    for( int i = 0; i < 8; i++ ) { _NOP(); } // Data hold time after CSW high
    PINL = 0b11111111; // Toggle bits
  }

  delay( 1000 );  // Give RAM time to degrade

  // Read back memory
  readAddr( 0x0000 );
  PORTA = 0xBE;
  DDRL = 0b00000000;
  PORTH = 0b00010000; // Set read

  uint8_t errors10 = 0;

  eval = 0xff;
  for( uint16_t i = 0; i < 0x4000; i++ )
  {
    PORTB = 0b00010000;
    for( int i = 0; i < 16; i++ ) { _NOP(); } // 8us+ CSR pulse
    errors10 |= PINL ^ eval;
    PORTB = 0b00110000; // Clear IORQ 
    eval ^= 0xff;
  }

  uint8_t errors_total = errors1 | errors0 | errors01 | errors10;
  bool pass = ( errors_total == 0 );
  
  for( uint8_t i = 0; errors_total != 0; i++, errors_total >>= 1 )
  {
    if( ( errors_total & 0b00000001 ) != 0 ) {
      Serial.print(
         ( char const *[] ) {
            "U16 ", "U14 ", "U12 ", "U10 ", "U17 ", "U15 ", "U13 ", "U11 "
         }[i]
      );
    }
  }

  if( pass ) {
    Serial.println( "VRAM test pass" );
  }
  else
  {
    Serial.println( " VRAM chips read incorrect" );
  }

  DDRA = 0b00000000; // Address low
  DDRC = 0b00000000; // Address high
  DDRL = 0b00000000; // Data
  PORTL = 0b00000000;
  PORTB = 0b00110000;
  DDRB = 0b00000000; // MREQ
  PORTH = 0b00110000;
  DDRH = 0b00000000; // RD, WR

  return pass;
}

static void printJoy( uint8_t in_num, uint8_t in_val ) {
  Serial.print( in_num );
  Serial.print( ": " );
  for( int i = 0; i < 8; i++, in_val >>= 1 ) {
    Serial.print(
      (char const *[]) { "N", "E", "S", "W", "Qt", "Ql", "B", "Qr" } [i] );
    Serial.print( ( ( in_val & 0b00000001 ) == 0 ) ? "+ " : "- " );
  }
  Serial.println();
}

static void printKey( uint8_t in_num, uint8_t in_val ) {
  Serial.print( in_num );
  Serial.print( ": " );

  Serial.print( (char const *[]) { "E0   ", "Key 8", "Key 4", "Key 5",
                                   "BLU  ", "Key 7", "Key #", "Key 2",
                                   "VIO  ", "Key *", "Key 0", "Key 9",
                                   "Key 3", "Key 1", "Key 6", "     " } [in_val & 0xf] );
  Serial.print( "       " );
  in_val >>= 4;
  for( int i = 0; i < 4; i++, in_val >>= 1 ) {
    Serial.print(
      (char const *[]) { "Qt", "Ql", "B", "Qr" } [i] );
    Serial.print( ( ( in_val & 0b00000001 ) == 0 ) ? "+ " : "- " );
  }
  Serial.println();
}

uint8_t joy0[16];
uint8_t joy1[16];
uint8_t key0[16];
uint8_t key1[16];

bool checkInput() {
  // We're going to keep printing until another input is received.  So clear the buffer of any 
  // immediate data
  delay(100);
  while( Serial.available() > 0 ) {
    Serial.read();
    delay(100);
  }

  bool pass = doBusAck();
  if( !pass ) {
    return pass;
  }

  // Set up for talking to controller ports
  DDRA = 0b11111111; // Address low
  DDRC = 0b11111111; // Address high
  PORTB = 0b00110000; // IORQ and MREQ off
  DDRB = 0b00110000; // IORQ and MREQ
  PORTD |= 0b00000001; // Turn off I/O override
  DDRH = 0b00110000; // RD, WR
  PORTH = 0b00110000; // No mode
  
  // Test that the quad input triggers INT
  // Start by testing that INT is not triggered
  if( ( PINB & 0b00000100 ) == 0 ) {
    Serial.println( "INT line is already active" );
    pass = false;
  }
  DDRB = 0b00111000;
  PORTB = 0b00111000;
  for( int i = 0; i < 16; i++ ) { _NOP(); }
  if( ( PINB & 0b00000100 ) != 0 ) {
    pass = false;
    Serial.println( "QUAD->INT trigger fail" );
  }
  DDRB = 0b00110000;
  PORTB = 0b00110000;
  // Wait for INT line to fall again
  while( ( PINB & 0b00000100 ) == 0 );

  uint8_t sweep = 0;
  bool last_int = false;
  uint8_t last_joy0 = 0;
  uint8_t last_joy1 = 0;
  uint8_t last_key0 = 0;
  uint8_t last_key1 = 0;
  while( Serial.available() == 0 ) {
    writeIO( 0xC0, 0 ); // Read joysticks
    for( int i = 0; i < 64; i++ ) { _NOP(); }
    joy0[sweep] = readIO( 0xFC );
    joy1[sweep] = readIO( 0xFF );

    writeIO( 0x80, 0 ); // Read keypads
    for( int i = 0; i < 8; i++ ) { _NOP(); }
    key0[sweep] = readIO( 0xFC );
    key1[sweep] = readIO( 0xFF );

    sweep++;
    sweep &= 0xf;

    // See if the sweep is debounced
    if( sweep == 0) {
      for( sweep = 0; sweep < 15; sweep++ ) {
        if( (joy0[sweep] & 0b00101111) != (joy0[sweep+1] & 0b00101111) ) {
          break;
        }
      }
      if( sweep == 15 ) {
        // Joystick 0 is stable
        if( (last_joy0 & 0b01111111) != (joy0[0] & 0b01111111) ) {
          last_joy0 = joy0[0];
          printJoy( 1, last_joy0 );
        }
      }

      for( sweep = 0; sweep < 15; sweep++ ) {
        if( (joy1[sweep] & 0b00101111) != (joy1[sweep+1] & 0b00101111) ) {
          break;
        }
      }
      if( sweep == 15 ) {
        // Joystick 1 is stable
        if( (last_joy1 & 0b01111111) != (joy1[0] & 0b01111111) ) {
          last_joy1 = joy1[0];
          printJoy( 2, last_joy1 );
        }
      }

      for( sweep = 0; sweep < 15; sweep++ ) {
        if( (key0[sweep] & 0b00101111) != (key0[sweep+1] & 0b00101111) ) {
          break;
        }
      }
      if( sweep == 15 ) {
        // Keypad 0 is stable
        if( (last_key0 & 0b01111111) != (key0[0] & 0b01111111) ) {
          last_key0 = key0[0];
          printKey( 1, last_key0 );
        }
      }

      for( sweep = 0; sweep < 15; sweep++ ) {
        if( (key1[sweep] & 0b00101111) != (key1[sweep+1] & 0b00101111) ) {
          break;
        }
      }
      if( sweep == 15 ) {
        // Keypad 1 is stable
        if( (last_key1 & 0b01111111) != (key1[0] & 0b01111111) ) {
          last_key1 = key1[0];
          printKey( 2, last_key1 );
        }
      }

      sweep = 0;
    }

    bool new_int = (PINB & 0b00000100) == 0;
    if( last_int != new_int ) {
      last_int = new_int;
      Serial.print( "Quad interrupt " );
      Serial.println( last_int ? "active" : "inactive" );
    }
  }

  Serial.read();

  return pass;
}
