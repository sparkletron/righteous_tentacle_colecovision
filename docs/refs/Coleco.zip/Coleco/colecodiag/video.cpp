#include <Arduino.h>
#include "tests.h"

bool doExtVideoTest()
{
  // Disable the CV CPU
  doBusAck();
  
  // Place in external video mode
  DDRF = 0b10011111;
  PORTF = 0b00010000;

  // Hold the peripheral clock
  DDRG = 0b00000001;
  PORTG = 0b00000000;

  int i;
  int j;
  
#define  PRE_EQ_PULSE 8
#define  PRE_EQ_GAP   90
#define  FIELD_SYNC_PULSE 86
#define  FIELD_SYNC_GAP 12
#define  POST_EQ_PULSE 8
#define  POST_EQ_GAP   90
#define  PRE_BLANK_FIELD_PULSE 14
#define  PRE_BLANK_FIELD_GAP   187
#define  FRONT_PORCH 4
#define  SYNC_PULSE 14
#define  BACK_PORCH 13
#define  VISIBLE_TIME 106
#define  VIDEO_ODD_LINES 262
#define  VIDEO_EVEN_LINES 262
#define  HALF_VISIBLE_TIME 50

  delay( 100 );
  while( Serial.available() ) { Serial.read(); delay( 100 ); }

  Serial.println( "Generating video" );

  // There are apparently a lot of interrupts for the Arduino to service.  That
  // completely screws timing, so we have to disable interrupts.  That means that
  // once video generation has started, resetting the board is currently the only
  // way back out.
  cli();

  TCNT1 = 0;
  
  // Begin showing a raster line
  do {
    // Pre-equalizing
    for( i = 6; i > 0; i-- ) {
      PORTF = 0b00000000;
      for( j = PRE_EQ_PULSE; j > 0; j-- ) {
        _NOP();
      }
      PORTF = 0b00010000;
      for( j = PRE_EQ_GAP; j > 0; j-- ) {
        _NOP();
      }
    }

    // Field sync
    for( i = 6; i > 0; i-- ) {
      PORTF = 0b00000000;
      for( j = FIELD_SYNC_PULSE; j > 0; j-- ) {
        _NOP();
      }
      PORTF = 0b00010000;
      for( j = FIELD_SYNC_GAP; j > 0; j-- ) {
        _NOP();
      }
    }

    // Post-equalizing
    for( i = 6; i > 0; i-- ) {
      PORTF = 0b00000000;
      for( j = POST_EQ_PULSE; j > 0; j-- ) {
        _NOP();
      }
      PORTF = 0b00010000;
      for( j = POST_EQ_GAP; j > 0; j-- ) {
        _NOP();
      }
    }

    for( i = 12; i > 0; i-- ) {
      PORTF = 0b00000000;
      for( j = PRE_BLANK_FIELD_PULSE; j > 0; j-- ) {
        _NOP();
      }
      PORTF = 0b00010000;
      for( j = PRE_BLANK_FIELD_GAP; j > 0; j-- ) {
        _NOP();
      }
    }

    for( i = VIDEO_ODD_LINES; i > 0; i-- ) {
      for( j = VISIBLE_TIME; j > 0; j-- ) {
        PORTF = (j ^ (i >> 4)) & 0b00001111 | 0b00010000;
      }
      PORTF = 0b00010000;
      for( j = FRONT_PORCH; j > 0; j-- ) {
        _NOP();
      }
      PORTF = 0b00000000;
      for( j = SYNC_PULSE; j > 0; j-- ) {
        _NOP();
      }
      PORTF = 0b00010000;
      for( j = BACK_PORCH; j > 0; j-- ) {
        _NOP();
      }
    }

    for( j = HALF_VISIBLE_TIME; j > 0; j-- ) {
      PORTF = (j ^ (i >> 4)) & 0b00001111 | 0b00010000;
    }

    for( i = 6; i > 0; i-- ) {
      PORTF = 0b00000000;
      for( j = PRE_EQ_PULSE; j > 0; j-- ) {
        _NOP();
      }
      PORTF = 0b00010000;
      for( j = PRE_EQ_GAP; j > 0; j-- ) {
        _NOP();
      }
    }

    for( i = 6; i > 0; i-- ) {
      PORTF = 0b00000000;
      for( j = FIELD_SYNC_PULSE; j > 0; j-- ) {
        _NOP();
      }
      PORTF = 0b00010000;
      for( j = FIELD_SYNC_GAP; j > 0; j-- ) {
        _NOP();
      }
    }
    
    for( i = 6; i > 0; i-- ) {
      PORTF = 0b00000000;
      for( j = POST_EQ_PULSE; j > 0; j-- ) {
        _NOP();
      }
      PORTF = 0b00010000;
      for( j = POST_EQ_GAP; j > 0; j-- ) {
        _NOP();
      }
    }

    for( j = HALF_VISIBLE_TIME; j > 0; j-- ) {
      _NOP();
    }
    
    for( i = 11; i > 0; i-- ) {
      PORTF = 0b00000000;
      for( j = PRE_BLANK_FIELD_PULSE; j > 0; j-- ) {
        _NOP();
      }
      PORTF = 0b00010000;
      for( j = PRE_BLANK_FIELD_GAP; j > 0; j-- ) {
        _NOP();
      }
    }

    for( j = HALF_VISIBLE_TIME; j > 0; j-- ) {
      PORTF = (j ^ (i >> 4)) & 0b00001111 | 0b00010000;
    }
    
    for( i = VIDEO_EVEN_LINES; i > 0; i-- ) {
      PORTF = 0b00010000;
      for( j = FRONT_PORCH; j > 0; j-- ) {
        _NOP();
      }
      PORTF = 0b00000000;
      for( j = SYNC_PULSE; j > 0; j-- ) {
        _NOP();
      }
      PORTF = 0b00010000;
      for( j = BACK_PORCH; j > 0; j-- ) {
        _NOP();
      }
      for( j = VISIBLE_TIME; j > 0; j-- ) {
        PORTF = (j ^ (i >> 4)) & 0b00001111 | 0b00010000;
      }
    }

    PORTF = 0b00010000;
    for( j = FRONT_PORCH; j > 0; j-- ) {
      _NOP();
    }
    PORTF = 0b00000000;
    for( j = SYNC_PULSE; j > 0; j-- ) {
      _NOP();
    }
    PORTF = 0b00010000;
    for( j = BACK_PORCH; j > 0; j-- ) {
      _NOP();
    }
    PORTF = 0b00011111;

    // Rather than trying to bit-bang the final half-line, I'll take this opportunity to
    // check for serial input
  } while( true );
}
