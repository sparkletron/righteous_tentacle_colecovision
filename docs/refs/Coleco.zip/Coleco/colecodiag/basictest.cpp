#include <arduino.h>
#include "tests.h"

bool doVoltageTest() {
  char out[80];

  bool good = true;
  
  uint32_t m5 = analogRead( A13 ); m5 = 1023 - m5; m5 = (m5 << 22) / 4294967;
  uint32_t p5 = analogRead( A14 ); p5 = (p5 << 22) / 4294967;
  uint32_t p12 = analogRead( A15 ); p12 = (p12 << 22) / 1789569;

  sprintf( out, "Voltages: -%d.%02d %d.%02d %d.%02d", 
          (uint16_t)(m5/100), (uint16_t)(m5 % 100),
          (uint16_t)(p5/100), (uint16_t)(p5 % 100),
          (uint16_t)(p12/100), (uint16_t)(p12 % 100));
  Serial.println( out );

  if( m5 < 475 || m5 > 525 ) {
    Serial.println( "-5V out of tolerance" );
    good = false;
  }
  if( p5 < 475 || p5 > 525 ) {
    Serial.println( "+5V out of tolerance" );
    good = false;
  }
  if( p12 < 1140 || p12 > 1260 ) {
    Serial.println( "+12V out of tolerance" );
    good = false;
  }

  return good;
}

bool doBusAck() {
  // Pull up MREQ and IORQ before tri-stating the bus
  DDRB = 0b00000000;
  PORTB = 0b00110000;
  // Also RD and WR
  DDRH = 0b00000000;
  PORTH = 0b00110000;
  
  // See if BUSACK is already asserted.  If so, did we do it?
  // And if that's the case, then good job, return.
  if( ( PINH & 0b00001000 ) == 0 ) // BUSACK
  {
    if( ( DDRD & 0b10000000 ) != 0 && // BUSRQ
        ( PORTD & 0b10000000 ) == 0 ) {
       return true;
    }
    Serial.println( "fail" );
    return false;
  }

  Serial.print( "BUSACK " );

  // Pull BUSRQ low
  DDRD = 0b10000000;
  PORTD = 0b00000000;

  // Wait for BUSACK
  uint16_t count;
  for( count = 0; count < 10000; count++ )
  {
    if( ( PINH & 0b00001000 ) == 0 ) // BUSACK
    {
      break;
    }
  }

  if( count < 10000 )
  {
    Serial.println( "pass" );
  }
  else
  {
    Serial.println( "fail" );
    DDRD = 0b00000000;
    PORTD = 0b00000000;
    return false;
  }

  return true;
}

static bool doClockTest()
{
  DDRG &= 0b11111000; // Clock lines are inputs
  PORTG &= 0b11111000; // Make sure they aren't pulling up

#define SAMPLE_CNT 250

  // Start by grabbing a bunch of samples.
  uint8_t samples[SAMPLE_CNT];
  for( uint8_t i = 0; i < SAMPLE_CNT; i++ )
  {
    samples[i] = PING;
  }

  // Make sure we only see the clock inputs
  for( uint8_t i = 0; i < SAMPLE_CNT; i++ )
  {
    samples[i] &= 0b00000111;
  }

  // See if the clock is alive
  // Now for some trivia:  The sampling loop above took 5 instructions per clock.  We're running at 16MHz, so 16/5MHz per sample.
  // So if the clock toggles at 7.16MHz and we sample at 3.2MHz, we can't exactly make sure the clock is at the correct speed.
  // What can be done, though, is to make sure there is SOME change in the clock signals.  All 3 bits ought to change.  Technically
  // with modulation this should happen within 16/5/abs(7.16-6.4) samples, which is just over 4.  So counting the samples should 
  // give an average of around 30 highs and 30 lows.  We'll be generous and check for 20.
  //
  // The original plan was to also check PCLK.  But it only has half the voltage of the main clock output, and never reads anything
  // but 0 with this Arduino.  Anyway, it's only separated from CLK by a passive voltage divider, so if the main clock works, I'll
  // deem that to have passed too.

  int clk0h = 0;
  int clk0l = 0;
  int clk1h = 0;
  int clk1l = 0;
  int pclkh = 0;
  int pclkl = 0;
  for( uint8_t i = 1; i < SAMPLE_CNT; i++ )
  {
    (samples[i] & 0b00000001) ? pclkh++ : pclkl++;
    (samples[i] & 0b00000010) ? clk1h++ : clk1l++;
    (samples[i] & 0b00000100) ? clk0h++ : clk0l++;
  }

  char msg[80];
  sprintf( msg, 
           "CLK0: %d:%d\n"
           "CLK1: %d:%d\n"
           //"PCLK: %d:%d\n"
           , clk0h, clk0l
           , clk1h, clk1l
           //, pclkh, pclkl
           );
  Serial.print( msg );

  bool pass = true;

  Serial.print( "CLK0 " );
  if( clk0h > 20 && clk0l > 20 )
  {
    Serial.println( "seems ok" );
  }
  else
  {
    pass = false;
    Serial.println( "fail" );
  }

  Serial.print( "CLK1 " );
  if( clk1h > 20 && clk1l > 20 )
  {
    Serial.println( "seems ok" );
  }
  else
  {
    pass = false;
    Serial.println( "fail" );
  }

//  Serial.print( "PCLK " );
//  if( pclkh > 20 && pclkl > 20 )
//  {
//    Serial.println( "seems ok" );
//  }
//  else
//  {
//    pass = false;
//    Serial.println( "fail" );
 // }

 return pass;
}

static bool doResetTest() {
  bool pass = true;
  
  // First check that RESET is in the correct resting state
  uint8_t s = PINB;
  if( ( s & 0b00000010 ) != 0 ) { // RESET
    Serial.print( "RESET" );
    Serial.println( " is stuck active" );
    pass = false;
  }

  if( ( s & 0b00000001 ) == 0 ) { // #RESET
    Serial.print( "#RESET" );
    Serial.println( " is stuck active" );
    if( ( s & 0b00000010 ) == 0 ) { // RESET
      Serial.println( "RESET is okay.  Therefore, likely problem with U7" );
    }
    pass = false;
  }

  // See if external reset works
  DDRD = 0b00000100;
  PORTD = 0b00000000;

  for( volatile uint8_t i = 0; i < 100; i++ );

  s = PINB;
  if( ( s & 0b00000010 ) == 0 ) { // RESET
    Serial.print( "RESET" );
    Serial.println( " did not respond to signal" );
    pass = false;
  }

  if( ( s & 0b00000001 ) != 0 ) { // #RESET
    Serial.print( "#RESET" );
    Serial.println( " did not respond to signal" );
    if( ( s & 0b00000010 ) != 0 ) { // RESET
      Serial.println( "RESET is okay.  Therefore, likely problem with U7" );
    }
    pass = false;
  }

  DDRD = 0b00000000;
  PORTD = 0b00000000;

  // If the reset circuit is broken, don't attempt to test any further
  if( !pass ) {
    return pass;
  }
  
  // Count the time it takes reset to fall inactive again.  Should be a few milliseconds
  uint32_t count;
  for( count = 0; ( PINB & 0b00000001 ) == 0; count++ ); // #RESET

  Serial.print( "RESET recovery time: " );
  Serial.println( count );
  if( count < 500 ) {
    Serial.println( "RESET capacitor may need to be replaced" );
    pass = false;
  }

  return pass;
}


static void printStuckPins( uint8_t data, uint8_t addrlow, uint8_t addrhigh, uint8_t buslines )
{
  for( int ct = 0; data != 0; data >>= 1, ct++ )
  {
    if( ( data & 1 ) != 0 )
    {
      Serial.print( " D" );
      Serial.print( ct );
    }
  }
  
  for( int ct = 0; addrlow != 0; addrlow >>= 1, ct++ )
  {
    if( ( addrlow & 1 ) != 0 )
    {
      Serial.print( " A" );
      Serial.print( ct );
    }
  }
  
  for( int ct = 8; addrhigh != 0; addrhigh >>= 1, ct++ )
  {
    if( ( addrhigh & 1 ) != 0 )
    {
      Serial.print( " A" );
      Serial.print( ct );
    }
  }

  for( int ct = 0; buslines != 0; buslines >>= 1, ct++ )
  {
    if( ( buslines & 1 ) != 0 )
    {
      Serial.print(   (char const *[]) {
                        " M1", " WR", " RD", " RFSH",
                        " MREQ", " IORQ"
                      } [ct] );
    }
  }
}


static bool checkStuckPinsForState( bool high )
{
  Serial.print( high ? "High" : "Low" );
  Serial.println( " stuck pins test" );

  uint8_t bitsl = 0b00000000;
  uint8_t bitsc = 0b00000000;
  uint8_t bitsa = 0b00000000;
  uint8_t bitsb = 0b00000000;
  uint8_t bitsh = 0b00000000;

  PORTH = high ? 0b00000000 : 0b00000010; // PULLUPSENSE


  // . .   .  .    .   .    .  .
  // . X   .  A3   .   A12  .  D4
  // . X   .  A5   .   A10  .  D2
  // . .   .  .    .   .    .  .
  //
  // . . . X  .    RD
  PORTK = 0b00000000;
  for( int i = 0; i < 10; i++ ) { _NOP(); }
  bitsa |= PINA & 0b00101000;
  bitsc |= PINC & 0b00010100;
  bitsl |= PINL & 0b00010100;
  bitsb |= PINB & 0b00000000;
  bitsh |= PINH & 0b00100000;


  // . .   .  .    .   .    .  .
  // X .   A2 .    A13 .    D5 .
  // . .   .  .    .   .    .  .
  // . X   .  A7   .   A8   .  D0
  //
  // X . . .  .    IORQ
  PORTK = 0b00000001;
  for( int i = 0; i < 10; i++ ) { _NOP(); }
  bitsa |= PINA & 0b10000100;
  bitsc |= PINC & 0b00100001;
  bitsl |= PINL & 0b00100001;
  bitsb |= PINB & 0b00100000;
  bitsh |= PINH & 0b00000000;


  // X .   A0 .    A15 .    D7 .
  // . .   .  .    .   .    .  .
  // . .   .  .    .   .    .  .
  // X .   A6 .    A9  .    D1 .
  //
  // . X . .  .    MREQ
  PORTK = 0b00000010;
  for( int i = 0; i < 10; i++ ) { _NOP(); } //while(Serial.read() != 'a');
  bitsa |= PINA & 0b01000001;
  bitsc |= PINC & 0b10000010;
  bitsl |= PINL & 0b10000010;
  bitsb |= PINB & 0b00010000;
  bitsh |= PINH & 0b00000000;


  // . X   .  A1   .   A14  .  D6
  // . .   .  .    .   .    .  .
  // X .   A4 .    A11 .    D3 .
  // . .   .  .    .   .    .  .
  //
  // . . . .  X    WR
  PORTK = 0b00000011;
  for( int i = 0; i < 10; i++ ) { _NOP(); }
  bitsa |= PINA & 0b00010010;
  bitsc |= PINC & 0b01001000;
  bitsl |= PINL & 0b01001000;
  bitsb |= PINB & 0b00000000;
  bitsh |= PINH & 0b00010000;


  if( !high )
  {
    bitsa ^= 0b11111111;
    bitsb ^= 0b00110000;
    bitsc ^= 0b11111111;
    bitsh ^= 0b00110000;
    bitsl ^= 0b11111111;
  }

  printStuckPins(
    bitsl,
    bitsa,
    bitsc,
    ((bitsb >> 4) | (bitsh >> 1)) );

  return (
    bitsl == 0 &&
    bitsa == 0 &&
    bitsc == 0 &&
    bitsb == 0 &&
    bitsh == 0 );
}
  
  
  
static bool doBusTest( )
{
  Serial.println( "Checking bus lines" );
  doBusAck();

  DDRK = 0b00000111; // Enable the pulling resistors
  
  DDRH = 0b00000010; // Drive the pullup sense line
  DDRA = 0b00000000; // Don't drive the address or data buses
  DDRC = 0b00000000;
  DDRL = 0b00000000;
  DDRB = 0b00000000; // Don't drive IORQ or MREQ

  PORTH = 0b00000000; // Turn off all pull-ups too
  PORTA = 0b00000000;
  PORTC = 0b00000000;
  PORTL = 0b00000000;
  PORTB = 0b00000000;

  bool result = 
  checkStuckPinsForState( true ) && 
  checkStuckPinsForState( false );

  // Disable the pulling resistors
  PORTK = 0b00000000;
  DDRK = 0b00000000;

  // Leave the BUSRQ line high for more tests
  PORTA = 0b00000000;
  PORTC = 0b00000000;
  PORTL = 0b00000000;

  if( result ) {
    Serial.println( "Bus test pass" );
  }
  
  return result;
}

static bool doRestingStateTest() {
  bool pass = true;

  Serial.println( "Checking resting state" );

  // Make sure all lines are at the correct resting state.
  uint8_t s = PINB;
  if( ( s & 0b10000000 ) == 0 ) { // AD4000
    Serial.print( "AD4000" );
    Serial.println( " is stuck active" );
    pass = false;
  }

  if( ( s & 0b01000000 ) == 0 ) { // AD2000
    Serial.println( "AD2000" );
    Serial.println( " is stuck active" );
    pass = false;
  }

  if( ( s & 0b00001000 ) == 1 ) { // QUAD
    Serial.println( "QUAD" );
    Serial.println( " is stuck active" );
    pass = false;
  }

  if( ( s & 0b00000100 ) == 0 ) { // INT
    Serial.print( "INT" );
    Serial.println( " is stuck active" );
    if( ( s & 0b00001000 ) == 0 ) {
      Serial.println( "QUAD is ok.  This suggests a problem with U7" );
    }
    pass = false;
  }

  s = PINE;
  if( ( s & 0b00001000 ) == 0 ) // NMI
  {
    Serial.print( "NMI" );
    Serial.println( " is stuck active" );
    pass = false;
  }

  if( pass ) {
    Serial.println( "Resting state looks okay" );
  }

  return pass;
}

static bool doWaitStateTest() {
  Serial.println( "Checking wait state" );
  
  // Activate M1 to see if the WAIT state begins to oscillate
  // First make sure wait state is low
  DDRJ = 0b00000010; // M1
  PORTJ = 0b00000010;

  _NOP();
  _NOP();
  _NOP();
  _NOP();

  if( ( PING & 0b00100000 ) == 0 ) { // WAIT
    Serial.println( "WAIT line is held low" );
    return false;
  }

  PORTJ = 0b00000000; // Activate M1

  // Grab a bunch of samples.
  uint8_t samples[SAMPLE_CNT];
  for( uint8_t i = 0; i < SAMPLE_CNT; i++ )
  {
    samples[i] = PING;
  }

  for( uint8_t i = 0; i < SAMPLE_CNT; i++ )
  {
    samples[i] &= 0b00100000; // WAIT
  }
  
  int waith = 0;
  int waitl = 0;
  for( uint8_t i = 1; i < SAMPLE_CNT; i++ )
  {
    samples[i] ? waith++ : waitl++;
  }

  char msg[80];
  sprintf( msg, 
           "WAIT: %d:%d\n"
           , waith, waitl
           );
  Serial.print( msg );

  Serial.print( "WAIT " );
  bool pass = true;
  if( waith > 20 && waitl > 20 )
  {
    Serial.println( "seems ok" );
  }
  else
  {
    Serial.println( "fail" );
    pass = false;
  }

  PORTJ = 0b00000000;
  DDRJ = 0b00000000;

  return pass;
}

bool doU5Test() {
  Serial.println( "Checking U5" );

  bool pass = true;

  // Test basic functionality of the memory selector (U5)
  DDRA = 0b11111111;
  PORTA = 0x00;
  DDRC = 0b11111111;
  PORTC = 0x20; // Set address in 0x2000 range so that AD2000 will be tested
  DDRL = 0b11111111;
  PORTL = 0x00;

  DDRD |= 0b00000010; // MEMMAPOVR
  DDRE = 0b00010000; // RFSH
  DDRB = 0b00010000; // MREQ

  // With memory override active, no AD2000 under any circumstance.  Try all 4
  // combinations
  PORTD = 0b00000000; // MEMMAPOVR is active
  PORTE = 0b00000000; // RFSH is active
  PORTB = 0b00100000; // Pull up IRQ and enable MREQ
  _NOP();
  _NOP();
  _NOP();
  _NOP();
  if( ( PINB & 0b01000000 ) == 0 ) { // AD2000 line should be inactive
    Serial.println( "U5 failed override refresh test");
    pass = false;
  }

  PORTB = 0b00110000; // Pull up IRQ and disable MREQ
  _NOP();
  _NOP();
  _NOP();
  _NOP();
  if( ( PINB & 0b01000000 ) == 0 ) { // AD2000 should still be inactive
    Serial.println( "U5 failed override RFSH quiesce test");
    pass = false;
  }

  PORTE = 0b00010000; // Disable RFSH.  MREQ is still inactive
  _NOP();
  _NOP();
  _NOP();
  _NOP();
  if( ( PINB & 0b01000000 ) == 0 ) { // AD2000 should still be inactive
    Serial.println( "U5 failed override quiesce test 2");
    pass = false;
  }

  PORTB = 0b00100000; // Pull up IRQ and enable MREQ
  _NOP();
  _NOP();
  _NOP();
  _NOP();
  if( ( PINB & 0b01000000 ) == 1 ) { // AD2000 should still be inactive
    Serial.println( "U5 failed override AD2000 decode test");
    while( Serial.read() != 'a' );
    pass = false;
  }

  // Allow memory mapping.
  PORTD |= 0b00000010;

  PORTE = 0b00000000; // RFSH active
  _NOP();
  _NOP();
  _NOP();
  _NOP();
  if( ( PINB & 0b01000000 ) == 0 ) { // AD2000 should still be inactive
    Serial.println( "U5 failed mapped refresh test");
    pass = false;
  }

  PORTB = 0b00110000; // Pull up IRQ and disable MREQ
  _NOP();
  _NOP();
  _NOP();
  _NOP();
  if( ( PINB & 0b01000000 ) == 0 ) { // AD2000 should still be inactive
    Serial.println( "U5 failed mapped RFSH quiesce test");
    pass = false;
  }

  PORTE = 0b00010000; // RFSH inactive
  _NOP();
  _NOP();
  _NOP();
  _NOP();
  if( ( PINB & 0b01000000 ) == 0 ) { // AD2000 should still be inactive
    Serial.println( "U5 failed quiesce test 2");
    pass = false;
  }

  // Finally all conditions are met that AD2000 should be selected
  PORTB = 0b00100000; // MREQ active
  _NOP();
  _NOP();
  _NOP();
  _NOP();
  if( ( PINB & 0b01000000 ) != 0 ) { // AD2000 should finally be active
    Serial.println( "U5 failed mapped decode AD2000 test");
    pass = false;
  }

  // See if AD4000 goes active
  PORTC = 0x40; // Address is 0x4000 now
  _NOP();
  _NOP();
  _NOP();
  _NOP();
  if( ( PINB & 0b10000000 ) != 0 ) {
    Serial.println( "U5 failed mapped decode AD4000 test");
    pass = false;
  }

  if( pass ) {
    Serial.println( "U5 pass" );
  }
  else
  {
    Serial.println( "U5 fail" );
  }

  // Return ports to input
  PORTB = 0b00110000;
  DDRB = 0b00000000;
  DDRC = 0b00000000;
  PORTC = 0b00000000;
  DDRE = 0b00000000;
  PORTE = 0b00000000;
  PORTD = 0b00000000;
  DDRD &= ~0b00000010;
  return pass;
}

void doBasicTests()
{
  doVoltageTest() &&
  doClockTest() &&
  doResetTest() &&
  doBusAck() &&
  doBusTest() &&
  doRestingStateTest() &&
  doWaitStateTest() &&
  doU5Test();
}
